document.getElementById("paymentForm").addEventListener("submit", function(event) {
    event.preventDefault(); //Stops form submitting 

    var card = document.getElementById("cardNumber").value; //Credit card number
    var month = document.getElementById("expMonth").value; //Expiry mopnth
    var year = document.getElementById("expYear").value; //Expiry year
    var cvv = document.getElementById("cvv").value; //CVV
    var message = document.getElementById("message"); //Placeholder for messages
  
    
    if (card.length != 16) { //Checks card number is 16 digits
      message.innerText = "Card number must be 16 digits."; //Message for wrong card length
      return; //Stop if validation fails
    }
  
    
    var start = card.substring(0, 2);
    if (start != "51" && start != "52" && start != "53" && start != "54" && start != "55") { //Check first two digits of card number
      message.innerText = "Card must start with 51, 52, 53, 54, or 55."; //Message if first two digits of card number are wrong
      return;
    }
  
   
    if (cvv.length != 3 && cvv.length != 4) {
      message.innerText = "CVV must be 3 or 4 digits."; //Error if CVV length is wrong
      return; //Stop if validation fails
    }
  
    
    var today = new Date(); //Get current date
    var thisYear = today.getFullYear(); //Get current year
    var thisMonth = today.getMonth() + 1; //Get current month
  
    if (Number(year) < thisYear) {
      message.innerText = "Card is expired."; //Error if year date is too early
      return; //Stop if validation fails
    }
  
    if (Number(year) == thisYear && Number(month) < thisMonth) {
      message.innerText = "Card is expired."; //Error if month is earlier than in current year
      return; //Stop if validation fails
    }
  
   
    var cardDetails = { 
      master_card: Number(card), //Change card number to a number
      exp_year: Number(year), //Change year to a number
      exp_month: Number(month), //Change month to a number
      cvv_code: cvv //Keep CVV as string
    };
  
    fetch("https://mudfoot.doc.stu.mmu.ac.uk/node/api/creditcard", {
      method: "POST", //Use POST to send data
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(cardDetails) //Turn card details to JSON string
    })
    .then(function(response) {
      return response.json(); //Get server response
    })
    .then(function(data) {
      if (data.message) { //Check data was validated
        sessionStorage.setItem("last4", card.slice(-4)); //Save last 4 card digits
        window.location.href = "success.html"; //Go to success page
      } else {
        message.innerText = "Payment was not accepted."; //Show error if failed
      }
    })
    .catch(function() { 
      message.innerText = "There was an error connecting to the server. Please try again in a moment."; //Message if something goes wrong
    });
  });
  
  